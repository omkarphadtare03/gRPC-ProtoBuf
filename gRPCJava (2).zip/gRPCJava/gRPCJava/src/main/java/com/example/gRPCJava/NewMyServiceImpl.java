package com.example.gRPCJava;

import com.yyyerhelp.grpc.MyServiceGrpc;
import com.yyyerhelp.grpc.Myservice;
import io.grpc.stub.StreamObserver;

class NewMyserviceImpl extends MyServiceGrpc.MyServiceImplBase
{
    @Override
    public void login(Myservice.LoginRequest request, StreamObserver<Myservice.APIResponse> responseObserver) {

        System.out.println("Inside Login");

        String username = request.getUsername();
        String password =request.getPassword();

        Myservice.APIResponse.Builder response = Myservice.APIResponse.newBuilder();

        if(username.equals(password))
        {
            System.out.println("login is successfull");
            response.setResponsecode(0).setResponsemessage("SUCCESS");
        }
        else
        {
            response.setResponsecode(1).setResponsemessage("Invalid");
        }
        responseObserver.onNext(response.build());
        responseObserver.onCompleted();
    }

    @Override
    public void logout(Myservice.Empty request, StreamObserver<Myservice.APIResponse> responseObserver) {

        System.out.println("......................Inside Logout ...................");


    }
}