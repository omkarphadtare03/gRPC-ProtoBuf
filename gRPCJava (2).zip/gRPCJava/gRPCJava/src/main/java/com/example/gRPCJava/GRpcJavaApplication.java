package com.example.gRPCJava;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;

@SpringBootApplication
public class GRpcJavaApplication {

	public static void main(String[] args) throws IOException, InterruptedException {
		SpringApplication.run(GRpcJavaApplication.class, args);

		Logger logger = LoggerFactory.getLogger(GRpcJavaApplication.class);

		Server server = ServerBuilder.forPort(9091)
				.addService(new NewMyserviceImpl()).build();
		server.start();

		logger.info("Server is Started"+server.getPort());

		server.awaitTermination();

	}

}
