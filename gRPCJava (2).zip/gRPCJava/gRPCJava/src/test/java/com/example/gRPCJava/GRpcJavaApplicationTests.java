package com.example.gRPCJava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GRpcJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
